# BolPay v7 – Phone-friendly Android starter

## What is ready
- Shopkeeper dashboard with today collection, all-time collection and transaction count.
- Persistent transaction history.
- Payment notification listener with conservative received/credited parsing and duplicate protection.
- Common payment-app source labels.
- High-priority payment alert and lock-screen visibility setting.
- Voice ON/OFF, 13 Indian-language choices, speech speed and volume.
- Test Payment ₹100.
- Demo login → ₹1 AutoPay setup → dashboard flow.
- GitHub Actions workflow that builds a debug APK in the cloud; no laptop and no local Gradle wrapper are required.

## Important limits
1. OTP/Google buttons are demo-only until real authentication is connected.
2. ₹1 AutoPay is demo-only until a compliant UPI mandate/payment gateway and backend are connected.
3. Notification parsing is not bank/UPI verification.
4. Android notification permission and Notification Access must be granted.
5. TTS support depends on installed Android voices.

## GitHub phone build
1. Put the contents of this project in the root of a GitHub repository (the `.github` folder must also be uploaded).
2. Open the repository's **Actions** tab.
3. Choose **Build BolPay APK**.
4. Tap **Run workflow** and select `main`.
5. When it finishes, open the workflow run and download the **BolPay-debug-apk** artifact.

No terminal command is needed after the project is uploaded correctly.
