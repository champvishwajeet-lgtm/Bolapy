package com.bolpay.app

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity:Activity(){
    private lateinit var root:LinearLayout
    private lateinit var collection:TextView
    private lateinit var count:TextView
    private lateinit var list:LinearLayout
    private lateinit var voiceButton:Button
    private var tts:TextToSpeech?=null
    private val langs=arrayOf("Hindi","English","Bengali","Marathi","Gujarati","Tamil","Telugu","Kannada","Malayalam","Punjabi","Assamese","Odia","Urdu")
    private val locales=mapOf("Hindi" to Locale("hi","IN"),"English" to Locale.ENGLISH,"Bengali" to Locale("bn","IN"),"Marathi" to Locale("mr","IN"),"Gujarati" to Locale("gu","IN"),"Tamil" to Locale("ta","IN"),"Telugu" to Locale("te","IN"),"Kannada" to Locale("kn","IN"),"Malayalam" to Locale("ml","IN"),"Punjabi" to Locale("pa","IN"),"Assamese" to Locale("as","IN"),"Odia" to Locale("or","IN"),"Urdu" to Locale("ur","IN"))

    override fun onCreate(b:Bundle?){super.onCreate(b); tts=TextToSpeech(this){}; if(!TransactionStore.loggedIn(this))showLogin() else if(!TransactionStore.autoPay(this))showAutoPay() else showDashboard()}
    override fun onDestroy(){tts?.shutdown();super.onDestroy()}
    override fun onResume(){super.onResume();if(::collection.isInitialized)refresh()}

    private fun tv(s:String,z:Float=16f,b:Boolean=false)=TextView(this).apply{text=s;textSize=z;if(b)setTypeface(null,1);setTextColor(Color.rgb(25,28,40));setPadding(14,10,14,10)}
    private fun base()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);setBackgroundColor(Color.rgb(246,247,251))}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;setOnClickListener{click()};isAllCaps=false}
    private fun card(v:View)=FrameLayout(this).apply{background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=24f};setPadding(10,10,10,10);addView(v)}

    private fun showLogin(){
        root=base();root.gravity=Gravity.CENTER_HORIZONTAL
        root.addView(tv("⚡ BOLPAY",34f,true));root.addView(tv("Aapka phone, aapka smart sound box.",17f))
        val mobile=EditText(this).apply{hint="Mobile number";inputType=2;setPadding(20,16,20,16)};root.addView(mobile,LinearLayout.LayoutParams(-1,-2))
        root.addView(button("Continue with Mobile OTP"){if(mobile.text.length>=10){TransactionStore.setLoggedIn(this,true);showAutoPay()}else Toast.makeText(this,"Enter a valid mobile number",Toast.LENGTH_SHORT).show()})
        root.addView(button("Continue with Google (Demo)"){TransactionStore.setLoggedIn(this,true);showAutoPay()})
        root.addView(tv("⚠ Prototype login: real OTP/Google verification will be connected later.",13f));setContentView(root)
    }

    private fun showAutoPay(){
        root=base();root.gravity=Gravity.CENTER_HORIZONTAL
        root.addView(tv("BOLPAY AUTOPAY",28f,true));root.addView(tv("₹1",58f,true));root.addView(tv("Free trial setup\nUPI AutoPay authorization",18f,true))
        root.addView(tv(if(TransactionStore.autoPay(this))"✓ AutoPay status: Enabled" else "AutoPay status: Not enabled",16f,true))
        root.addView(button("Continue to UPI / Start ₹1 Trial"){AlertDialog.Builder(this).setTitle("UPI AutoPay Authorization").setMessage("Real UPI mandate will be connected later through a compliant payment gateway. Nothing is charged by this demo.").setPositiveButton("Approve Demo"){_,_->TransactionStore.setAutoPay(this,true);showDashboard()}.setNegativeButton("Cancel",null).show()})
        root.addView(button("Continue without AutoPay"){showDashboard()});setContentView(root)
    }

    private fun showDashboard(){
        root=base();root.addView(tv("⚡ BOLPAY",30f,true));root.addView(tv("Har payment ki awaaz, seedha aapke phone par."))
        val stats=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        collection=tv("",27f,true);collection.gravity=Gravity.CENTER;stats.addView(collection)
        count=tv("",15f);count.gravity=Gravity.CENTER;stats.addView(count);root.addView(card(stats))
        root.addView(tv(if(enabled())"● Payment notifications: ON" else "○ Payment notifications: OFF",14f,true))
        root.addView(button("🔔 Enable Payment Notifications"){try{startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))}catch(_:Exception){}})
        root.addView(button("🔊 Test Payment ₹100"){addTest(100.0)})
        val languageButton=button("🌐 Voice Language: ${TransactionStore.language(this)}"){}
        languageButton.setOnClickListener{chooseLanguage(languageButton)}
        root.addView(languageButton)
        voiceButton=button(""){ };root.addView(voiceButton);updateVoice()
        root.addView(button("⚙ Voice & Alert Settings"){showSettings()})
        root.addView(button("🗑 Clear Demo Transactions"){TransactionStore.clear(this);refresh()})
        root.addView(tv("Recent Transactions",21f,true))
        val sc=ScrollView(this);list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(root);refresh()
    }

    private fun refresh(){if(!::collection.isInitialized)return;val a=TransactionStore.all(this);collection.text="Today's Collection  ₹${money(TransactionStore.todayTotal(this))}";count.text="${a.size} total transactions  •  ₹${money(TransactionStore.total(this))} all-time";list.removeAllViews();if(a.isEmpty())list.addView(tv("No payments yet. Real received notifications will appear here.",15f)) else a.take(50).forEach{t->val d=SimpleDateFormat("dd MMM, hh:mm a",Locale.getDefault()).format(Date(t.time));val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,10,12,10);background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=18f}};row.addView(tv("₹${money(t.amount)}   •   ${t.status}",18f,true));row.addView(tv("$d  •  ${t.source}",13f));list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,6,0,6)})}}
    private fun addTest(a:Double){TransactionStore.add(this,a,"Demo");refresh();if(TransactionStore.voiceOn(this))speak(a);Toast.makeText(this,"Test payment added",Toast.LENGTH_SHORT).show()}

    private fun speak(a:Double){val lang=TransactionStore.language(this);val locale=locales[lang]?:Locale.ENGLISH;val n=if(a%1.0==0.0)a.toInt().toString() else String.format(Locale.US,"%.2f",a);tts?.language=if((tts?.isLanguageAvailable(locale)?:-1)>=0)locale else Locale.ENGLISH;tts?.setSpeechRate(TransactionStore.speechRate(this));val params=Bundle().apply{putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,TransactionStore.volume(this@MainActivity))};val p=when(lang){"Hindi"->if(n=="100")"एक सौ रुपये प्राप्त हुए हैं।" else if(n=="500")"पाँच सौ रुपये प्राप्त हुए हैं।" else if(n=="1000")"एक हजार रुपये प्राप्त हुए हैं।" else "$n रुपये प्राप्त हुए हैं।";"English"->"₹$n received.";"Bengali"->"₹$n টাকা পাওয়া গেছে।";"Marathi"->"₹$n रुपये प्राप्त झाले आहेत।";"Gujarati"->"₹$n રૂપિયા પ્રાપ્ત થયા છે।";"Tamil"->"₹$n பெறப்பட்டது।";"Telugu"->"₹$n అందింది।";"Kannada"->"₹$n ಸ್ವೀಕರಿಸಲಾಗಿದೆ.";"Malayalam"->"₹$n ലഭിച്ചു.";"Punjabi"->"₹$n ਪ੍ਰਾਪਤ ਹੋਏ ਹਨ।";"Assamese"->"₹$n লাভ কৰা হৈছে।";"Odia"->"₹$n ଟଙ୍କା ପ୍ରାପ୍ତ ହୋଇଛି।";"Urdu"->"₹$n موصول ہوئے ہیں۔";else->"₹$n received."};tts?.speak(p,TextToSpeech.QUEUE_FLUSH,params,"test")}
    private fun chooseLanguage(b:Button){AlertDialog.Builder(this).setTitle("Voice Language").setSingleChoiceItems(langs,langs.indexOf(TransactionStore.language(this))){d,w->TransactionStore.setLanguage(this,langs[w]);b.text="🌐 Voice Language: ${langs[w]}";d.dismiss()}.show()}
    private fun updateVoice(){voiceButton.text=if(TransactionStore.voiceOn(this))"🔊 Voice Alert: ON" else "🔇 Voice Alert: OFF";voiceButton.setOnClickListener{TransactionStore.setVoice(this,!TransactionStore.voiceOn(this));updateVoice()}}

    private fun showSettings(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,4,20,4)}
        val lock=Switch(this).apply{text="Lock-screen payment alert";isChecked=TransactionStore.lockAlert(this@MainActivity)};box.addView(lock)
        val speed=SeekBar(this).apply{max=10;progress=((TransactionStore.speechRate(this@MainActivity)-0.5f)*10).toInt()};box.addView(tv("Speech speed: ${String.format(Locale.US,"%.1fx",TransactionStore.speechRate(this))}"));box.addView(speed)
        val vol=SeekBar(this).apply{max=8;progress=((TransactionStore.volume(this@MainActivity)-0.2f)*10).toInt()};box.addView(tv("Speech volume: ${String.format(Locale.US,"%.0f%%",TransactionStore.volume(this)*100)}"));box.addView(vol)
        val speedLabel=box.getChildAt(1) as TextView;val volLabel=box.getChildAt(3) as TextView
        speed.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,f:Boolean){val v=0.5f+p/10f;speedLabel.text="Speech speed: ${String.format(Locale.US,"%.1fx",v)}";TransactionStore.setSpeechRate(this@MainActivity,v)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){} })
        vol.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,f:Boolean){val v=0.2f+p/10f;volLabel.text="Speech volume: ${String.format(Locale.US,"%.0f%%",v*100)}";TransactionStore.setVolume(this@MainActivity,v)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){} })
        AlertDialog.Builder(this).setTitle("BolPay Voice & Alerts").setView(box).setPositiveButton("Save"){_,_->TransactionStore.setLockAlert(this,lock.isChecked);Toast.makeText(this,"Settings saved",Toast.LENGTH_SHORT).show()}.setNegativeButton("Cancel",null).show()
    }
    private fun enabled()=Settings.Secure.getString(contentResolver,"enabled_notification_listeners")?.contains(packageName)==true
    private fun money(x:Double)=if(x%1.0==0.0)x.toInt().toString() else String.format(Locale.US,"%.2f",x)
}
