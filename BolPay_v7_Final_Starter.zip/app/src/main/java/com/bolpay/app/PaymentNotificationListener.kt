package com.bolpay.app

import android.app.*
import android.content.Context
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.util.Locale

class PaymentNotificationListener:NotificationListenerService(){
    private var tts:TextToSpeech?=null
    private val seen=HashMap<String,Long>()
    private val locales=mapOf(
        "Hindi" to Locale("hi","IN"),"English" to Locale.ENGLISH,"Bengali" to Locale("bn","IN"),
        "Marathi" to Locale("mr","IN"),"Gujarati" to Locale("gu","IN"),"Tamil" to Locale("ta","IN"),
        "Telugu" to Locale("te","IN"),"Kannada" to Locale("kn","IN"),"Malayalam" to Locale("ml","IN"),
        "Punjabi" to Locale("pa","IN"),"Assamese" to Locale("as","IN"),"Odia" to Locale("or","IN"),
        "Urdu" to Locale("ur","IN"))

    override fun onCreate(){
        super.onCreate()
        tts=TextToSpeech(this){if(it==TextToSpeech.SUCCESS) tts?.language=locales[TransactionStore.language(this)]?:Locale.ENGLISH}
        createChannel()
    }
    override fun onDestroy(){tts?.shutdown();super.onDestroy()}

    override fun onNotificationPosted(sbn:StatusBarNotification){
        if(sbn.packageName==packageName)return
        val e=sbn.notification.extras?:return
        val body=(e.getString(Notification.EXTRA_TITLE).orEmpty()+" "+
                e.getCharSequence(Notification.EXTRA_TEXT).orEmpty()+" "+
                e.getCharSequence(Notification.EXTRA_BIG_TEXT).orEmpty()).trim()
        if(body.isBlank())return
        val l=body.lowercase(Locale.ROOT)
        val positive=listOf("received","credited","payment received","money received","paid you","cashback received","प्राप्त","जमा","मिले","मिला","पैसे आए","राशि प्राप्त")
        val negative=listOf("sent","debited","debit","paid to","payment sent","भुगतान किया","भेजा गया","withdrawn","withdrawal")
        if(!positive.any{l.contains(it)}||negative.any{l.contains(it)})return
        val pattern="""(?:₹|rs\.?|inr)\s*([0-9,]+(?:\.[0-9]{1,2})?)"""
        val amount=Regex(pattern,RegexOption.IGNORE_CASE).find(body)?.groupValues?.getOrNull(1)?.replace(",","")?.toDoubleOrNull()?:return
        val now=System.currentTimeMillis(); val key="${sbn.packageName}|$amount|${body.take(180)}"
        if(now-(seen[key]?:0L)<15000)return
        seen[key]=now; seen.entries.removeIf{now-it.value>60000}

        val source=sourceName(sbn.packageName)
        TransactionStore.add(this,amount,source)
        if(TransactionStore.voiceOn(this)) speak(amount)
        showAlert(amount,source)
    }

    private fun sourceName(pkg:String)=when(pkg){
        "com.google.android.apps.nbu.paisa.user"->"Google Pay"
        "net.one97.paytm"->"Paytm"
        "com.phonepe.app"->"PhonePe"
        "in.org.npci.upiapp"->"BHIM"
        else->pkg.substringAfterLast('.').replaceFirstChar{if(it.isLowerCase())it.titlecase(Locale.ROOT) else it.toString()}
    }

    private fun speak(a:Double){
        val lang=TransactionStore.language(this); val locale=locales[lang]?:Locale.ENGLISH
        val available=tts?.isLanguageAvailable(locale)?:TextToSpeech.LANG_NOT_SUPPORTED
        val finalLocale=if(available<0) Locale.ENGLISH else locale
        tts?.language=finalLocale
        tts?.setSpeechRate(TransactionStore.speechRate(this))
        val params=Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,TransactionStore.volume(this@PaymentNotificationListener)) }
        val n=if(a%1.0==0.0)a.toInt().toString() else String.format(Locale.US,"%.2f",a)
        val p=phrase(lang,n)
        tts?.speak(p,TextToSpeech.QUEUE_FLUSH,params,"payment")
    }

    private fun phrase(lang:String,n:String)=when(lang){
        "Hindi"->if(n=="100")"एक सौ रुपये प्राप्त हुए हैं।" else if(n=="500")"पाँच सौ रुपये प्राप्त हुए हैं।" else if(n=="1000")"एक हजार रुपये प्राप्त हुए हैं।" else "$n रुपये प्राप्त हुए हैं।"
        "English"->"₹$n received."
        "Bengali"->"₹$n টাকা পাওয়া গেছে।"
        "Marathi"->"₹$n रुपये प्राप्त झाले आहेत।"
        "Gujarati"->"₹$n રૂપિયા પ્રાપ્ત થયા છે।"
        "Tamil"->"₹$n பெறப்பட்டது।"
        "Telugu"->"₹$n అందింది।"
        "Kannada"->"₹$n ಸ್ವೀಕರಿಸಲಾಗಿದೆ।"
        "Malayalam"->"₹$n ലഭിച്ചു।"
        "Punjabi"->"₹$n ਪ੍ਰਾਪਤ ਹੋਏ ਹਨ।"
        "Assamese"->"₹$n লাভ কৰা হৈছে।"
        "Odia"->"₹$n ଟଙ୍କା ପ୍ରାପ୍ତ ହୋଇଛି।"
        "Urdu"->"₹$n موصول ہوئے ہیں۔"
        else->"₹$n received."
    }

    private fun createChannel(){
        val nm=getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("payments","Payment Alerts",NotificationManager.IMPORTANCE_HIGH).apply{
            description="BolPay payment received alerts"
            setShowBadge(true)
            lockscreenVisibility=if(TransactionStore.lockAlert(this@PaymentNotificationListener)) Notification.VISIBILITY_PUBLIC else Notification.VISIBILITY_PRIVATE
        })
    }

    private fun showAlert(a:Double,source:String){
        val n=if(a%1.0==0.0)a.toInt().toString() else String.format(Locale.US,"%.2f",a)
        val msg=when(TransactionStore.language(this)){"Hindi"->"₹$n प्राप्त हुए हैं।";"English"->"₹$n received.";else->"₹$n received."}
        val builder=Notification.Builder(this,"payments")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("BolPay • Payment Received")
            .setContentText(msg)
            .setStyle(Notification.BigTextStyle().bigText("$msg\nSource: $source"))
            .setAutoCancel(true).setCategory(Notification.CATEGORY_MESSAGE)
            .setVisibility(if(TransactionStore.lockAlert(this))Notification.VISIBILITY_PUBLIC else Notification.VISIBILITY_PRIVATE)
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis()%100000).toInt(),builder.build())
    }
}
