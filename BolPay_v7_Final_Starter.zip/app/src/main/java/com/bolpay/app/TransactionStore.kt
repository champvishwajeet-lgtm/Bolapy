package com.bolpay.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Tx(val amount:Double,val time:Long,val source:String,val status:String)

object TransactionStore {
    private const val PREF="bolpay_store"
    private const val KEY="transactions"
    private fun p(c:Context)=c.getSharedPreferences(PREF,Context.MODE_PRIVATE)

    @Synchronized fun add(c:Context,amount:Double,source:String,status:String="Received") {
        val a=JSONArray(p(c).getString(KEY,"[]"))
        val o=JSONObject().apply {
            put("amount",amount); put("time",System.currentTimeMillis()); put("source",source); put("status",status)
        }
        val out=JSONArray().apply { put(o) }
        for(i in 0 until minOf(a.length(),199)) out.put(a.getJSONObject(i))
        p(c).edit().putString(KEY,out.toString()).apply()
    }

    fun all(c:Context):List<Tx> {
        val a=JSONArray(p(c).getString(KEY,"[]"))
        return buildList {
            for(i in 0 until a.length()) {
                val o=a.getJSONObject(i)
                add(Tx(o.optDouble("amount"),o.optLong("time"),o.optString("source"),o.optString("status")))
            }
        }
    }

    fun total(c:Context)=all(c).sumOf{it.amount}
    fun todayTotal(c:Context):Double {
        val cal=Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY,0); cal.set(Calendar.MINUTE,0); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0)
        val start=cal.timeInMillis
        return all(c).filter{it.time>=start}.sumOf{it.amount}
    }
    fun clear(c:Context)=p(c).edit().remove(KEY).apply()

    fun voiceOn(c:Context)=p(c).getBoolean("voice",true)
    fun setVoice(c:Context,v:Boolean)=p(c).edit().putBoolean("voice",v).apply()
    fun lockAlert(c:Context)=p(c).getBoolean("lock_alert",true)
    fun setLockAlert(c:Context,v:Boolean)=p(c).edit().putBoolean("lock_alert",v).apply()
    fun language(c:Context)=p(c).getString("lang","Hindi")?:"Hindi"
    fun setLanguage(c:Context,v:String)=p(c).edit().putString("lang",v).apply()
    fun speechRate(c:Context)=p(c).getFloat("speech_rate",1.0f)
    fun setSpeechRate(c:Context,v:Float)=p(c).edit().putFloat("speech_rate",v.coerceIn(0.5f,1.5f)).apply()
    fun volume(c:Context)=p(c).getFloat("volume",1.0f)
    fun setVolume(c:Context,v:Float)=p(c).edit().putFloat("volume",v.coerceIn(0.2f,1.0f)).apply()

    fun loggedIn(c:Context)=p(c).getBoolean("logged",false)
    fun setLoggedIn(c:Context,v:Boolean)=p(c).edit().putBoolean("logged",v).apply()
    fun autoPay(c:Context)=p(c).getBoolean("autopay",false)
    fun setAutoPay(c:Context,v:Boolean)=p(c).edit().putBoolean("autopay",v).apply()
}
